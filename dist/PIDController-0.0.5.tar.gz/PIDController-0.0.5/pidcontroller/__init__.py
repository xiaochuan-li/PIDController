from .PIDController import Variable, PIDController

__version__ = '0.0.5'

def sayit():
    print("Now you have me! ({})".format(__version__))